/*
  script.js
  Henry Suh
  301004212
  Sep 28th, 2021
*/



